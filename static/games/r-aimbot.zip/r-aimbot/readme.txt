R-Aimbot v1.0 by w@ko0 

VAC2 - Undetected 18 July, 2012

Features: 
- Aimbot
- AutoAim
- KnifeAim
- AutoWall
- AutoShoot
- AutoPistol
- Team
- NoRecoil
- NoSpread


Support games:
- Counter-Strike 1.6 (4554)

Support OS:
- Windows XP/Vista/7 x32 & x64

Changelog: 
v1.0 (18 July, 2012)
- First release (Aimbot, Autoaim, KnifeAim, AutoWall,
AutoShoot, AutoPistol, Team, NoRecoil and NoSpread)

Instructions:
- Run r-aimbot.exe
- Start game
- Join server

Enjoy!

Visit my official blog wako-hacks.blogspot.com